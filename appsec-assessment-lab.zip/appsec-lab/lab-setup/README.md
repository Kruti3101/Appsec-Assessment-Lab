# Lab setup

Everything here runs locally and binds to `127.0.0.1` only. Nothing in this lab
should ever be exposed to a network you do not control.

## Web targets

```bash
cd lab-setup
docker compose up -d
```

| Target | URL | Useful for |
|---|---|---|
| OWASP Juice Shop | http://127.0.0.1:3000 | Modern JS stack; authorization and business logic flaws |
| DVWA | http://127.0.0.1:8080 | Injection and file upload, with adjustable difficulty |
| MobSF | http://127.0.0.1:8000 | Static analysis of APKs |

DVWA needs a one-time database setup: open the URL, click **Create / Reset
Database**, then log in with the default credentials shown on that page.

Raising DVWA's security level from Low to Medium to High is worth doing. Low
teaches you the vulnerability; High teaches you why weak fixes fail, which is
the part that makes your remediation advice credible.

## Mobile targets

1. Install Android Studio and create an emulator (API 30+, x86_64).
2. Download a deliberately vulnerable APK:
   - [InsecureBankv2](https://github.com/dineshshetty/Android-InsecureBankv2)
   - [OWASP DIVA](https://github.com/payatu/diva-android)
3. Install it: `adb install app.apk`
4. Upload the same APK to MobSF at http://127.0.0.1:8000 for static analysis.

## Intercepting mobile traffic

Burp needs its CA in the emulator's system trust store:

```bash
# Convert Burp's exported DER certificate to Android's expected format
openssl x509 -inform DER -in burp.der -out burp.pem
mv burp.pem "$(openssl x509 -inform PEM -subject_hash_old -in burp.pem | head -1).0"

adb root && adb remount
adb push <hash>.0 /system/etc/security/cacerts/
adb shell chmod 644 /system/etc/security/cacerts/<hash>.0
adb reboot
```

Then point the emulator's proxy at your host IP and Burp's listener port.

If traffic still does not appear, the app is likely pinning certificates.
Record that either way — whether pinning is present or absent is itself a
finding worth noting under MASVS-NETWORK.

## Teardown

```bash
docker compose down -v
```
