# Web application testing methodology

Aligned to the [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
(WSTG). The point of working from a published methodology rather than ad-hoc
poking is coverage you can defend: when someone asks "did you check for X",
the answer is a checklist entry, not a memory.

## Scope

Only applications running locally in this lab, on infrastructure I control:

- OWASP Juice Shop
- DVWA (Damn Vulnerable Web Application)

Testing any system you do not own or have written permission to test is
unlawful in most jurisdictions. Nothing in this repository should be pointed at
a third-party host.

## Phases

### 1. Reconnaissance and mapping (WSTG-INFO)

Enumerate the attack surface before testing it. Walk the application as a normal
user first — every page, every form, every role — and record what you find.

- Map routes, parameters, and file upload points
- Identify the technology stack from headers and error pages
- Note authentication boundaries and where roles change
- Record the entry points in `tracking/attack-surface.md`

### 2. Configuration and deployment (WSTG-CONF)

- Security headers: CSP, HSTS, `X-Content-Type-Options`, `Referrer-Policy`
- Cookie attributes: `Secure`, `HttpOnly`, `SameSite`
- TLS configuration and certificate validity
- Exposed admin interfaces, backup files, verbose error pages

### 3. Authentication and session management (WSTG-ATHN, WSTG-SESS)

- Credential handling in transit and at rest
- Account lockout and rate limiting on login
- Session token entropy, rotation on privilege change, invalidation on logout
- Password reset flow: token predictability, expiry, single use

### 4. Authorization (WSTG-ATHZ)

The category that finds the most real bugs, because it cannot be automated well.

- Horizontal access control: can user A read user B's records by changing an ID?
- Vertical access control: can a standard user reach admin functionality?
- Direct object references in URLs, request bodies, and API responses
- Forced browsing to endpoints not linked in the UI

### 5. Input validation (WSTG-INPV)

- Injection: SQL, command, template, LDAP
- Cross-site scripting: reflected, stored, DOM-based
- Server-side request forgery
- File upload handling: type validation, path traversal, stored location

### 6. Business logic (WSTG-BUSL)

- Workflow steps that can be skipped or replayed
- Client-side-only validation of price, quantity, or role
- Race conditions on state-changing operations

## Recording results

One finding per file in `findings/`, using `findings/TEMPLATE.md`. Fill in the
YAML front matter completely — the tooling reads it, and a finding without a
CVSS vector cannot be prioritised.

Rate every finding with `python tools/cvss.py "<vector>"` and record both the
vector and the rationale. A score with no reasoning behind the metric choices
is not defensible in a triage meeting.

## What good evidence looks like

Evidence should let a developer reproduce and fix the issue. It should not be a
copy-paste weapon.

- Describe the condition (input reflected unencoded) rather than shipping a
  working exploit chain
- Redact tokens, session identifiers, and credentials from captures
- Screenshots go in `evidence/`, referenced by filename from the finding
- Note the exact build or commit tested, so a retest is meaningful
