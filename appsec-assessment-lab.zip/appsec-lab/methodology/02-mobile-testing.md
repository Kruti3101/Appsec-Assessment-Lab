# Mobile application testing methodology

Aligned to the [OWASP Mobile Application Security Verification Standard](https://mas.owasp.org/MASVS/)
(MASVS) and the Mobile Application Security Testing Guide (MASTG).

Mobile changes the threat model in one important way: the attacker may have the
device. Anything shipped in the APK — keys, endpoints, logic — should be treated
as readable by whoever installs it.

## Scope

Deliberately vulnerable Android applications, installed on an emulator I
control:

- InsecureBankv2
- OWASP DIVA (Damn Insecure and Vulnerable App)

Do not decompile or test applications you do not own. Reverse engineering a
third-party app usually violates its licence terms regardless of intent.

## Static analysis (MASTG static tests)

Run [MobSF](https://github.com/MobSF/Mobile-Security-Framework-MobSF) against
the APK first — it gives a fast inventory, and its findings are the starting
point rather than the conclusion. Every automated finding gets manually
confirmed before it becomes a finding file.

### MASVS-STORAGE — data storage

- Sensitive data written to SharedPreferences, SQLite, or external storage
- Data written to logs (`Log.d` with account details is the classic)
- Keys or credentials hardcoded in source, resources, or `strings.xml`
- Backup flags: `android:allowBackup` permitting extraction over ADB

### MASVS-CRYPTO — cryptography

- Hardcoded or derived-from-constant encryption keys
- Deprecated algorithms and modes: DES, RC4, ECB, MD5, SHA-1 for security use
- Static initialisation vectors
- Whether the Android Keystore is used for key material

### MASVS-AUTH — authentication

- Authentication decisions made client-side
- Credential caching and biometric prompt handling
- Session token storage location and lifetime

### MASVS-PLATFORM — platform interaction

- Exported activities, services, receivers, and content providers
- WebView configuration: `setJavaScriptEnabled`, `addJavascriptInterface`,
  file access from a WebView
- Deep link and intent filter validation
- Permissions requested versus permissions actually used

### MASVS-CODE — code quality

- Debuggable builds shipped
- Third-party library versions with known vulnerabilities
- Obfuscation and whether it matters for the identified risk

## Dynamic analysis

- Intercept traffic through Burp Suite with a proxy CA installed on the emulator
- Confirm certificate pinning is present or absent, and note which
- Inspect files written at runtime under `/data/data/<package>/`
- Exercise exported components with `adb shell am start` to test whether they
  enforce their own authorization

## Network layer

- Cleartext HTTP anywhere in the app, including analytics and ad SDKs
- `android:usesCleartextTraffic` and the network security configuration
- Certificate and hostname validation, including custom TrustManagers

## Recording results

Same workflow as web: one file per finding in `findings/`, MASVS control ID in
the `masvs` front matter field, CVSS vector scored with `tools/cvss.py`.

Mobile findings frequently score lower than their web equivalents because
Attack Vector is Local rather than Network — the attacker needs the device.
Score it honestly. A hardcoded key in an APK is a real issue, but it is not
remotely exploitable, and inflating the vector to make it look urgent damages
your credibility with the developers you need to persuade.
