# Triage, risk rating, and remediation tracking

Finding a vulnerability is the easy half. The half that matters to an
organisation is deciding what to fix first and confirming it actually got
fixed.

## Rating

Every finding gets a CVSS v3.1 base vector, scored with `tools/cvss.py`. Record
the vector, not just the number — the vector is the reasoning, and it is what
someone will challenge in a triage meeting.

Choosing metrics honestly matters more than choosing them severely:

| Metric | Ask |
|---|---|
| Attack Vector | Reachable from the internet, the local network, or only with the device in hand? |
| Attack Complexity | Does exploitation need conditions outside the attacker's control? |
| Privileges Required | Does the attacker need an account first? An admin account? |
| User Interaction | Must a victim click something? |
| Scope | Does impact cross a security boundary into another component? |
| C / I / A | What is actually exposed, altered, or denied — not worst case imaginable |

Base score is not the whole story. Base score describes the vulnerability;
priority describes the vulnerability in a specific environment. A Medium on an
internet-facing service handling personal data usually outranks a High on an
internal tool behind a VPN. Record that reasoning in the finding.

## Priority mapping

| CVSS | Severity | Target remediation |
|---|---|---|
| 9.0–10.0 | Critical | 7 days |
| 7.0–8.9 | High | 30 days |
| 4.0–6.9 | Medium | 90 days |
| 0.1–3.9 | Low | Next planned release |

These are lab defaults modelled on common SLA structures. A real programme sets
these against regulatory obligations and risk appetite, not a table copied from
a repository.

## Workflow

Findings move through a fixed set of states, enforced by `tools/track.py`:

```
open → in-remediation → retest → closed
                    ↘ risk-accepted
```

- **open** — confirmed, rated, not yet assigned
- **in-remediation** — a developer owns it and a fix is in progress
- **retest** — fix is deployed to the test build, awaiting verification
- **closed** — retested and verified fixed; retest date recorded
- **risk-accepted** — a decision was made not to fix; record who accepted it
  and why. This state exists because pretending every finding gets fixed is
  the fastest way to lose credibility.

Nothing moves to **closed** without a retest entry. "The developer said it was
fixed" is not verification.

## Exporting to a tracker

Findings are written as markdown, but developers work in an issue tracker:

```bash
python tools/track.py export --format jira --out reports/jira-import.csv
```

The output maps to Jira's default CSV import fields, with CVSS severity mapped
to Jira priority. Each ticket carries the target, the vector, the impact, and
the remediation steps, so the developer does not have to come back and ask what
the finding means.

## Writing remediation guidance developers will act on

The difference between a finding that gets fixed and one that sits open for two
quarters is usually the quality of the remediation section.

- Name the specific fix, not the category. "Use parameterised queries in
  `getUserOrders()`" beats "sanitise input".
- Give the defence-in-depth control as well as the fix, so a regression is not
  immediately exploitable again.
- Suggest the test that prevents recurrence — a unit test, a lint rule, a CI
  gate. Findings that come back are findings that were never really closed.
- Explain the impact in terms of the business, not the tool. "An unauthenticated
  user can read any customer's order history" lands; "CWE-639" does not.
