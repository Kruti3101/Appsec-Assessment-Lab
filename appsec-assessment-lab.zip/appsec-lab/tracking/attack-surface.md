# Attack surface inventory

Record the entry points found during reconnaissance, before testing them.
Coverage you can point at is the difference between an assessment and a
collection of interesting bugs.

## OWASP Juice Shop

| Route | Method | Parameters | Auth required | Tested |
|---|---|---|---|---|
| `/#/search` | GET | `q` | No | Yes |
| | | | | |

## DVWA

| Route | Method | Parameters | Auth required | Tested |
|---|---|---|---|---|
| | | | | |

## Android target

| Component | Type | Exported | Notes | Tested |
|---|---|---|---|---|
| | | | | |
