"""Assessment report generator.

Builds a single markdown summary report from every finding in findings/:
a risk breakdown, a remediation status table, and per-finding detail. This is
the artifact you would hand to a development team or attach to a ticket.

Usage:
    python tools/report.py --out reports/assessment-report.md
    python tools/report.py --out reports/web-only.md --target "OWASP Juice Shop"
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from track import SEVERITY_RANK, load_all  # noqa: E402

SEVERITIES = ["Critical", "High", "Medium", "Low", "None"]


def build_report(findings: list[dict], scope: str | None = None) -> str:
    counts = {sev: 0 for sev in SEVERITIES}
    for f in findings:
        counts[f["severity"]] += 1

    open_items = [f for f in findings if f["status"] not in ("closed", "risk-accepted")]
    closed_items = [f for f in findings if f["status"] == "closed"]

    lines: list[str] = []
    lines.append("# Application Security Assessment Report")
    lines.append("")
    lines.append(f"**Generated:** {date.today().isoformat()}  ")
    lines.append(f"**Scope:** {scope or 'All targets in this lab'}  ")
    lines.append(f"**Findings:** {len(findings)} total, {len(open_items)} open, "
                 f"{len(closed_items)} closed")
    lines.append("")
    lines.append("All testing was performed against intentionally vulnerable "
                 "applications running locally, in a lab environment owned by the "
                 "tester. No third-party systems were in scope.")
    lines.append("")

    lines.append("## Risk summary")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("|---|---|")
    for sev in SEVERITIES:
        if counts[sev]:
            lines.append(f"| {sev} | {counts[sev]} |")
    lines.append("")

    lines.append("## Remediation status")
    lines.append("")
    lines.append("| ID | Finding | Severity | CVSS | Status | Retested |")
    lines.append("|---|---|---|---|---|---|")
    for f in findings:
        lines.append(
            f"| {f['id']} | {f['title']} | {f['severity']} | {f['cvss_score']} "
            f"| {f['status']} | {f['retested'] or '—'} |"
        )
    lines.append("")

    lines.append("## Findings in detail")
    lines.append("")
    for f in findings:
        lines.append(f"### {f['id']} — {f['title']}")
        lines.append("")
        lines.append(f"**Target:** {f['target']}  ")
        lines.append(f"**Category:** {f['category']}  ")
        refs = " · ".join(x for x in [f["cwe"], f["masvs"], f["wstg"]] if x)
        if refs:
            lines.append(f"**References:** {refs}  ")
        lines.append(f"**CVSS v3.1:** {f['cvss_score']} ({f['severity']}) "
                     f"`{f['cvss_vector']}`  ")
        lines.append(f"**Status:** {f['status']}")
        lines.append("")
        lines.append(f["body"])
        lines.append("")

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate an assessment report.")
    parser.add_argument("--out", required=True, help="output markdown path")
    parser.add_argument("--target", help="only include findings for this target")
    args = parser.parse_args()

    findings = load_all()
    if args.target:
        findings = [f for f in findings if f["target"] == args.target]

    if not findings:
        print("No findings to report.", file=sys.stderr)
        return 1

    findings.sort(key=lambda f: (SEVERITY_RANK[f["severity"]], -f["cvss_score"]))

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build_report(findings, args.target), encoding="utf-8")
    print(f"Report written to {out} ({len(findings)} finding(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
