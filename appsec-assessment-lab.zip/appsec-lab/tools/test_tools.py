"""Tests for the scoring and tracking tools.

Run with: python -m pytest tools/ -v

The CVSS cases are checked against scores produced by the official FIRST
calculator. A scoring tool that is subtly wrong is worse than no tool, because
every finding downstream inherits the error.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from cvss import CvssError, base_score, roundup, severity  # noqa: E402
from track import FindingError, split_front_matter  # noqa: E402


# --- CVSS base scores -------------------------------------------------------

@pytest.mark.parametrize(
    "vector,expected",
    [
        ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", 9.8),
        ("AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", 6.1),
        ("AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H", 8.8),
        ("AV:L/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", 6.2),
        ("AV:N/AC:H/PR:H/UI:R/S:U/C:L/I:L/A:L", 3.9),
        ("AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", 10.0),
        ("AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", 5.5),
    ],
)
def test_base_score(vector: str, expected: float) -> None:
    assert base_score(vector) == expected


def test_no_impact_scores_zero() -> None:
    """A vector with no C/I/A impact must score 0.0, whatever the exploitability."""
    assert base_score("AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:N") == 0.0


def test_scope_changed_raises_score() -> None:
    """Identical impact metrics score higher when scope changes."""
    unchanged = base_score("AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:L")
    changed = base_score("AV:N/AC:L/PR:N/UI:N/S:C/C:L/I:L/A:L")
    assert changed > unchanged


def test_privileges_required_weighting_differs_by_scope() -> None:
    """PR:L is weighted differently when scope is Changed — a real spec subtlety."""
    unchanged = base_score("AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H")
    changed = base_score("AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H")
    assert changed != unchanged


# --- roundup behaviour ------------------------------------------------------

def test_roundup_rounds_up_not_to_nearest() -> None:
    """CVSS roundup always rounds up; plain rounding would give 4.0 here."""
    assert roundup(4.01) == 4.1
    assert roundup(4.00) == 4.0


# --- severity mapping -------------------------------------------------------

@pytest.mark.parametrize(
    "score,expected",
    [
        (0.0, "None"),
        (3.9, "Low"),
        (4.0, "Medium"),
        (6.9, "Medium"),
        (7.0, "High"),
        (8.9, "High"),
        (9.0, "Critical"),
        (10.0, "Critical"),
    ],
)
def test_severity_boundaries(score: float, expected: str) -> None:
    assert severity(score) == expected


# --- vector validation ------------------------------------------------------

def test_missing_metric_rejected() -> None:
    with pytest.raises(CvssError, match="missing required metrics"):
        base_score("AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H")


def test_unknown_metric_value_rejected() -> None:
    with pytest.raises(CvssError):
        base_score("AV:X/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")


def test_malformed_metric_rejected() -> None:
    with pytest.raises(CvssError, match="Malformed"):
        base_score("AVN/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")


# --- finding parsing --------------------------------------------------------

def test_front_matter_parses() -> None:
    meta, body = split_front_matter("---\nid: F-1\nstatus: open\n---\n\n## Summary\n")
    assert meta["id"] == "F-1"
    assert "Summary" in body


def test_missing_front_matter_rejected() -> None:
    with pytest.raises(FindingError, match="front matter"):
        split_front_matter("## Summary\n\nNo front matter here.\n")


def test_unclosed_front_matter_rejected() -> None:
    with pytest.raises(FindingError, match="not closed"):
        split_front_matter("---\nid: F-1\n")


def test_example_finding_is_valid() -> None:
    """The example shipped in the repo must itself parse and score."""
    from track import load_finding

    path = Path(__file__).resolve().parent.parent / "findings" / "EXAMPLE-001-reflected-xss.md"
    finding = load_finding(path)
    assert finding["cvss_score"] == 6.1
    assert finding["severity"] == "Medium"
    assert finding["status"] == "closed"
