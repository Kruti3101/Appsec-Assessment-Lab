---
id: EXAMPLE-001
title: Reflected cross-site scripting in search parameter
target: OWASP Juice Shop (lab instance)
category: Injection
cwe: CWE-79
wstg: WSTG-INPV-01
cvss_vector: AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N
status: closed
found: 2026-01-15
retested: 2026-01-22
---

> **This is a worked example**, kept in the repo to show the expected level of
> detail. It is not a live finding. Replace it with your own as you test.

## Summary

The search feature reflects user-supplied input into the response without
output encoding. A crafted link causes attacker-controlled script to run in
the victim's browser under the application's origin. Because the payload
travels in a URL, it is deliverable by email or chat and needs no prior
access to the application.

## Affected component

- **Endpoint:** `GET /#/search`
- **Parameter:** `q`
- **Build tested:** Juice Shop v15 (local Docker instance)

## Evidence

Confirmed by submitting a benign marker string containing angle brackets and
observing that it was returned inside the HTML body unescaped, rather than
encoded as `&lt;` and `&gt;`. A DOM inspection showed the marker parsed as an
element node instead of text. Screenshot: `evidence/example-001-dom.png`.

```
Request:  GET /#/search?q=<MARKER>
Response: ...<span>...<MARKER>...</span>...   # marker parsed as markup, not text
```

No live payload is recorded here by design — the condition is demonstrated by
the encoding failure, which is what a developer needs to act on.

## Impact

Script executing in the application's origin can read session state accessible
to JavaScript, act as the user against application endpoints, or render
convincing credential-harvesting content on a legitimate domain. Scope is
rated Changed because execution crosses into the browser's security context.

Confidentiality and Integrity are rated Low rather than High: the lab instance
holds no production data, and exploitation requires the victim to open a
crafted link (User Interaction: Required).

## Remediation

1. **Encode on output.** Escape user input contextually at render time —
   HTML-entity encoding for element content, attribute encoding for attribute
   values. Use the framework's built-in interpolation rather than assigning to
   `innerHTML`.
2. **Add a Content-Security-Policy** with a strict `script-src` and no
   `unsafe-inline`, so a missed encoding does not become code execution.
3. **Add a regression test** asserting that a marker string is returned
   encoded, so the fix cannot silently regress.

## Retest

| Date | Build | Result | Notes |
|---|---|---|---|
| 2026-01-22 | v15 + patch | Pass | Marker returned HTML-encoded; CSP present in response headers |
