---
id: FINDING-000
title: Short description of the issue
target: Application name and version
category: Injection | Broken Access Control | Insecure Storage | Cryptography | Auth
cwe: CWE-000
masvs: MASVS-STORAGE-1        # mobile findings only; delete for web
wstg: WSTG-INPV-05            # web findings only; delete for mobile
cvss_vector: AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
status: open                  # open | in-remediation | retest | closed | risk-accepted
found: YYYY-MM-DD
retested: ''
---

## Summary

One paragraph: what the issue is, where it occurs, and why it matters in
business terms rather than tool output.

## Affected component

- **Endpoint / screen:** `/path/or/Activity`
- **Parameter / field:** `name`
- **Build tested:** version or commit

## Evidence

Describe how the issue was confirmed. Reference a screenshot in
`evidence/` rather than pasting raw exploit payloads.

```
Redacted request/response excerpt or tool output showing the condition
```

## Impact

What an attacker gains. Tie this to the CVSS vector above — if you rated
Confidentiality as High, explain what data is exposed.

## Remediation

Concrete, developer-facing guidance:

1. The specific fix (parameterised queries, output encoding, keystore usage).
2. The defence-in-depth control that limits impact if the fix regresses.
3. The test or lint rule that stops it coming back.

## Retest

| Date | Build | Result | Notes |
|---|---|---|---|
| | | | |
